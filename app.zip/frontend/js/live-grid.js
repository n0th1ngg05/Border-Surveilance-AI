/*
 * live-grid.js
 *
 * The real camera grid: <video> elements playing the local MP4s (served at
 * /videos/N.mp4 by boot.ts) with a <canvas> overlay per tile drawing YOLO
 * bounding boxes from live Socket.IO detection events.
 *
 * WHY THIS FILE OWNS ITS OWN DOM NODE, NOT A CHILD OF #view:
 * The rest of this app re-renders its whole page via `view.innerHTML = ...`
 * on every store change (see app.js render()), and live detection events
 * are exactly the kind of thing that trigger those rerenders. If the actual
 * <video>/<canvas> elements lived inside #view, `innerHTML = ...` would
 * destroy and recreate them (restarting playback from frame 0) many times a
 * second. Instead, this module keeps ONE permanent host element appended
 * directly to <body>, completely outside #view's subtree, and "portals" it
 * on top of wherever the current page put its placeholder
 * (#live-grid-mount) by copying that placeholder's bounding box onto the
 * host every animation frame. The host is never touched by app.js's render
 * cycle, so video playback and canvas overlays are never interrupted.
 *
 * Public API (used by pages.js):
 *   window.liveGrid.mount(placeholderEl, opts)        -> shows grid over placeholder
 *   window.liveGrid.mountSolo(placeholderEl, cameraId) -> shows single tile over placeholder
 *   window.liveGrid.unmount()                          -> hides host, stops videos/sockets
 */
(function () {
  const BOX_TTL_MS = 900; // how long a bbox stays drawn after its detection event
  const BOX_COLOR = { human: "#f2c14e", vehicle: "#5ecbe0" };

  let hostEl = null; // permanent, lives in <body>, never destroyed by app.js
  let placeholderEl = null; // the page's throwaway #live-grid-mount div we track
  let tiles = new Map(); // cameraId -> { video, canvas, ctx, wrap, boxes: [] }
  let unsubDetection = null;
  let unsubConnection = null;
  let soloMode = false;
  let trackRaf = null;

  function ensureHost() {
    if (hostEl) return hostEl;
    hostEl = document.createElement("div");
    hostEl.id = "live-grid-host";
    hostEl.style.position = "fixed";
    hostEl.style.zIndex = "5";
    hostEl.style.pointerEvents = "none"; // re-enabled per-tile below
    hostEl.style.display = "none";
    document.body.appendChild(hostEl);
    return hostEl;
  }

  function trackPlaceholder() {
    if (!placeholderEl || !hostEl) return;
    if (!placeholderEl.isConnected) {
      // The page navigated away / rerendered without our placeholder —
      // caller is responsible for calling unmount() via page.onLeave, but
      // hide defensively so we never show a grid floating over a page that
      // no longer wants it.
      hostEl.style.display = "none";
      trackRaf = requestAnimationFrame(trackPlaceholder);
      return;
    }
    const rect = placeholderEl.getBoundingClientRect();
    hostEl.style.display = "block";
    hostEl.style.top = rect.top + "px";
    hostEl.style.left = rect.left + "px";
    hostEl.style.width = rect.width + "px";
    hostEl.style.height = rect.height + "px";
    trackRaf = requestAnimationFrame(trackPlaceholder);
  }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
    })[c]);
  }

  function buildTile(camera, opts) {
    const o = opts || {};
    const wrap = document.createElement("div");
    wrap.className = "panel cam-tile live-tile";
    wrap.dataset.cameraId = camera.id;
    wrap.style.pointerEvents = "auto"; // host disables pointer-events; re-enable per-tile

    const shot = document.createElement("div");
    shot.className =
      "cam-shot live-shot" +
      (camera.feedType === "thermal" ? " thermal" : "") +
      (camera.status === "warning" ? " warning" : "");

    const video = document.createElement("video");
    video.src = window.LIVE.videoUrl(camera.id);
    video.autoplay = true;
    video.loop = true;
    video.muted = true;
    video.playsInline = true;
    video.className = "live-video";

    const canvas = document.createElement("canvas");
    canvas.className = "live-canvas";

    shot.appendChild(video);
    shot.appendChild(canvas);

    const badgeTl = document.createElement("span");
    badgeTl.className = "cam-badge tl";
    badgeTl.innerHTML =
      '<span class="dot bg-ok"></span><span class="num">' + esc(camera.id.toUpperCase()) + "</span>";
    shot.appendChild(badgeTl);

    const badgeTr = document.createElement("span");
    badgeTr.className = "cam-badge tr";
    badgeTr.innerHTML = '<span class="dot bg-accent live-dot"></span><span class="num">LIVE</span>';
    shot.appendChild(badgeTr);

    const caption = document.createElement("span");
    caption.className = "cam-caption";
    caption.innerHTML =
      '<span style="min-width:0"><span class="name truncate" style="display:block">' +
      esc(camera.name) +
      "</span>" +
      (o.compact
        ? ""
        : '<span class="loc truncate" style="display:block">' + esc(camera.location || "") + "</span>") +
      "</span>";
    shot.appendChild(caption);

    if (!o.solo) {
      shot.addEventListener("click", () => {
        if (typeof o.onOpen === "function") o.onOpen(camera.id);
      });
      shot.style.cursor = "pointer";
    }

    wrap.appendChild(shot);

    video.play().catch(() => {
      /* Autoplay can be blocked before first user gesture — video.muted
         should satisfy the browser policy, but ignore failures quietly. */
    });

    return { wrap, shot, video, canvas, ctx: canvas.getContext("2d"), boxes: [] };
  }

  function resizeCanvas(tile) {
    const rect = tile.shot.getBoundingClientRect();
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = Math.max(2, rect.width);
    const h = Math.max(2, rect.height);
    tile.canvas.width = Math.round(w * dpr);
    tile.canvas.height = Math.round(h * dpr);
    tile.canvas.style.width = w + "px";
    tile.canvas.style.height = h + "px";
    tile.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    tile.cssW = w;
    tile.cssH = h;
  }

  function drawTile(tile) {
    const ctx = tile.ctx;
    ctx.clearRect(0, 0, tile.cssW, tile.cssH);
    if (!tile.boxes.length) return;

    const now = performance.now();
    tile.boxes = tile.boxes.filter((b) => now - b.at < BOX_TTL_MS);

    tile.boxes.forEach((b) => {
      const age = (now - b.at) / BOX_TTL_MS;
      const alpha = Math.max(0, 1 - age);
      const color = BOX_COLOR[b.kind] || "#f2c14e";

      // Scale from the source frame's pixel space to this tile's CSS size.
      // Fall back to a native-video-size guess if the payload had no
      // frame_width/height (e.g. demo-ticker events with no real bbox).
      const srcW = b.frameWidth || tile.video.videoWidth || tile.cssW;
      const srcH = b.frameHeight || tile.video.videoHeight || tile.cssH;
      const sx = tile.cssW / srcW;
      const sy = tile.cssH / srcH;

      const [x1, y1, x2, y2] = b.bbox;
      const rx = x1 * sx;
      const ry = y1 * sy;
      const rw = (x2 - x1) * sx;
      const rh = (y2 - y1) * sy;

      ctx.globalAlpha = alpha;
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.strokeRect(rx, ry, rw, rh);

      const label = (b.label || b.kind) + (b.confidence ? " " + Math.round(b.confidence * 100) + "%" : "");
      ctx.font = "700 11px 'Archivo', sans-serif";
      const textW = ctx.measureText(label).width;
      ctx.fillStyle = color;
      ctx.globalAlpha = alpha * 0.88;
      ctx.fillRect(rx, Math.max(0, ry - 16), textW + 8, 16);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = "#0b0d10";
      ctx.fillText(label, rx + 4, Math.max(11, ry - 4));
    });

    ctx.globalAlpha = 1;
  }

  function tick() {
    tiles.forEach((tile) => {
      if (!tile.wrap.isConnected) return;
      drawTile(tile);
    });
    rafHandle = requestAnimationFrame(tick);
  }

  let rafHandle = null;

  function applyDetection(evt) {
    const tile = tiles.get(evt.cameraId);
    if (!tile || !evt.detections.length) return;
    const now = performance.now();
    evt.detections.forEach((d) => {
      tile.boxes.push({
        at: now,
        bbox: d.bbox,
        label: d.label,
        confidence: d.confidence,
        kind: evt.kind,
        frameWidth: evt.frameWidth,
        frameHeight: evt.frameHeight,
      });
    });
  }

  function setConnDot(connected) {
    document.querySelectorAll(".live-tile .cam-badge.tr .dot").forEach((dot) => {
      dot.classList.toggle("bg-accent", connected);
      dot.classList.toggle("bg-warn", !connected);
    });
  }

  let currentKey = null; // "wall:3x2" | "solo:cam-01" | null — what's actually built right now

  function clearTiles() {
    tiles.forEach((tile) => {
      tile.video.pause();
      tile.video.removeAttribute("src");
      tile.video.load();
    });
    tiles.clear();
    if (hostEl) hostEl.innerHTML = "";
  }

  function stopStreams() {
    if (rafHandle) cancelAnimationFrame(rafHandle);
    if (trackRaf) cancelAnimationFrame(trackRaf);
    rafHandle = null;
    trackRaf = null;
    if (unsubDetection) unsubDetection();
    if (unsubConnection) unsubConnection();
    unsubDetection = null;
    unsubConnection = null;
  }

  /** Fully stop everything — call when navigating away from the Monitor page. */
  function teardown() {
    stopStreams();
    clearTiles();
    currentKey = null;
    placeholderEl = null;
    if (hostEl) hostEl.style.display = "none";
    window.removeEventListener("resize", onResize);
  }

  function onResize() {
    tiles.forEach(resizeCanvas);
  }

  async function buildWall(cameras, opts) {
    const o = opts || {};
    clearTiles();
    const grid = document.createElement("div");
    grid.className = "wall live-wall l" + (o.layout || "3x2");
    hostEl.appendChild(grid);

    cameras.forEach((camera) => {
      const tile = buildTile(camera, { onOpen: o.onOpen });
      grid.appendChild(tile.wrap);
      tiles.set(camera.id, tile);
    });

    requestAnimationFrame(() => tiles.forEach(resizeCanvas));
  }

  async function buildSolo(camera) {
    clearTiles();
    const tile = buildTile(camera, { solo: true });
    tile.shot.classList.add("cam-solo-shot");
    tile.wrap.style.height = "100%";
    hostEl.appendChild(tile.wrap);
    tiles.set(camera.id, tile);

    requestAnimationFrame(() => tiles.forEach(resizeCanvas));
  }

  function startLiveStreams() {
    if (unsubDetection) return; // already running
    window.addEventListener("resize", onResize);
    unsubDetection = window.LIVE.onDetection(applyDetection);
    unsubConnection = window.LIVE.onConnectionChange(setConnDot);
    if (!rafHandle) rafHandle = requestAnimationFrame(tick);
  }

  /**
   * Show the wall grid, positioned over `el` (the page's #live-grid-mount
   * placeholder). Idempotent for the same layout — calling this again with
   * an unchanged layout only re-tracks the placeholder's position, it does
   * NOT rebuild tiles or restart video.
   */
  async function mount(el, opts) {
    const o = opts || {};
    const key = "wall:" + (o.layout || "3x2");
    ensureHost();
    placeholderEl = el;
    if (!trackRaf) trackRaf = requestAnimationFrame(trackPlaceholder);

    if (currentKey === key) return; // same wall already built — just keep tracking position
    currentKey = key;
    soloMode = false;

    let cameras;
    try {
      cameras = await window.LIVE.getCameras();
    } catch (err) {
      hostEl.innerHTML =
        '<div class="panel" style="padding:3rem 1.5rem;text-align:center"><p class="small">Could not reach the surveillance backend.</p><p class="xsmall muted" style="margin-top:0.5rem">' +
        esc(err.message) +
        "</p></div>";
      return;
    }
    if (currentKey !== key) return; // mount target changed while awaiting

    if (!cameras.length) {
      hostEl.innerHTML =
        '<div class="panel" style="padding:3rem 1.5rem;text-align:center"><p class="small">No cameras registered.</p></div>';
      return;
    }

    await buildWall(cameras, o);
    startLiveStreams();
  }

  /** Same idempotency behavior as mount(), keyed by camera id. */
  async function mountSolo(el, cameraId) {
    const key = "solo:" + cameraId;
    ensureHost();
    placeholderEl = el;
    if (!trackRaf) trackRaf = requestAnimationFrame(trackPlaceholder);

    if (currentKey === key) return;
    currentKey = key;
    soloMode = true;

    let cameras;
    try {
      cameras = await window.LIVE.getCameras();
    } catch (err) {
      hostEl.innerHTML = '<p class="small" style="padding:2rem">Could not reach backend.</p>';
      return;
    }
    if (currentKey !== key) return;

    const camera = cameras.find((c) => c.id === cameraId) || cameras[0];
    if (!camera) return;

    await buildSolo(camera);
    startLiveStreams();
  }

  window.liveGrid = {
    mount: mount,
    mountSolo: mountSolo,
    unmount: teardown,
  };
})();
