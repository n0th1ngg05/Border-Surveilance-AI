/* ─────────────────────────────────────────────────────────
   V.I.E.W Dashboard Controller
   Pre-seeded with complete military demo data
───────────────────────────────────────────────────────── */

const API = '';
let socket = null;
let activeEventId = null;

/* ── DOM REFS ──────────────────────────────────────────── */
const elDeviceList = document.getElementById('device-list');
const elEventsList = document.getElementById('events-list-feed');
const elEvdId = document.getElementById('evd-id');
const elEvdType = document.getElementById('evd-type');
const elEvdTime = document.getElementById('evd-time');
const elEvdCam = document.getElementById('evd-cam');
const elEvdLoc = document.getElementById('evd-loc');
const elEvdEntity = document.getElementById('evd-entity');
const elFocalLabel = document.getElementById('focal-node-label');
const elCaseCount = document.getElementById('case-open-count');
const elBadgeEvents = document.getElementById('badge-events');
const elBtnBreach = document.getElementById('btn-trigger-breach');

/* Modal Refs */
const backdrop = document.getElementById('modal-backdrop');
const modals = document.querySelectorAll('.modal');
const closeBtns = document.querySelectorAll('.modal-close, .mbtn-ghost[data-modal]');

/* ── DEMO DATA STORE ───────────────────────────────────── */
const demoStore = {
  cameras: [
    { id: 'cam-01', name: 'Sector 4 — North Border Fence', loc: 'Grid Ref 32.74N 74.88E', rtsp: 'rtsp://10.1.4.101/live/sec4_th', status: 'active', fps: 30, res: '1920x1080 (Thermal)', type: 'thermal' },
    { id: 'cam-02', name: 'Checkpost Alpha — Main Gate', loc: 'Grid Ref 32.72N 74.85E', rtsp: 'rtsp://10.1.4.102/live/gate1', status: 'active', fps: 30, res: '2560x1440 (ANPR Edge)', type: 'optical' },
    { id: 'cam-03', name: 'Tower Bravo — Riverine Basin', loc: 'Grid Ref 32.76N 74.91E', rtsp: 'rtsp://10.1.4.103/live/twr2_ir', status: 'warning', fps: 25, res: '1920x1080 (LR-IR)', type: 'ir' },
    { id: 'cam-04', name: 'Patrol Corridor Charlie', loc: 'Grid Ref 32.70N 74.82E', rtsp: 'rtsp://10.1.4.104/live/ridge_nv', status: 'active', fps: 30, res: '1920x1080 (Starlight NV)', type: 'optical' }
  ],
  personnel: [
    { id: 'BSF-2021-4401', name: 'SM Rajesh Kumar', rank: 'Officer', unit: '14th Rajputana', station: 'Post Alpha', status: 'on-duty', verified: '2 mins ago' },
    { id: 'BSF-2022-8112', name: 'HAV Amit Sharma', rank: 'NCO', unit: '8th Mountain Div', station: 'Gate 1', status: 'on-duty', verified: '4 mins ago' },
    { id: 'BSF-2023-1094', name: 'NK Gurpreet Singh', rank: 'OR', unit: '14th Sikh LI', station: 'Tower Bravo', status: 'on-patrol', verified: '1 min ago' },
    { id: 'BSF-2023-5520', name: 'L/NK Vikram Rathore', rank: 'OR', unit: 'Sector 4 QRT', station: 'Ridge Delta', status: 'on-patrol', verified: '3 mins ago' },
    { id: 'BSF-2024-9182', name: 'SEP Sunil Soren', rank: 'OR', unit: 'Border Guard Unit', station: 'Post Alpha', status: 'on-duty', verified: 'Just now' }
  ],
  vehicles: [
    { plate: '22D 109284K', type: 'Combat (Marksman)', unit: 'QRT', status: 'verified', cp: 'Checkpost Alpha (08:32)' },
    { plate: '19B 847219M', type: 'Combat (BMP-2)', unit: '4th Armoured', status: 'verified', cp: 'Sector 4 (07:15)' },
    { plate: '20C 551928L', type: 'Transport (Stallion)', unit: 'Logistics Dep.', status: 'verified', cp: 'Gate 1 Inbound (09:12)' },
    { plate: 'DL 01 AB 4912', type: 'Civilian SUV (White)', unit: 'UNKNOWN', status: 'flagged', cp: 'Checkpost Alpha (FLAGGED)' }
  ],
  alerts: [
    { id: 'ALERT-101', level: 'HIGH', type: 'intrusion', msg: '🚨 INTRUSION: Unknown entity crossed Zero-Line', cam: 'Sector 4 — North Border Fence', loc: 'Zero-Line Restricted Zone', entity: 'TARGET-091', time: new Date(Date.now() - 35000).toISOString(), status: 'open' },
    { id: 'ALERT-102', level: 'MEDIUM', type: 'unauthorized_vehicle', msg: '⚠️ ANPR MISMATCH: Civilian SUV DL 01 AB 4912', cam: 'Checkpost Alpha — Main Gate', loc: 'Checkpost Alpha', entity: 'DL 01 AB 4912', time: new Date(Date.now() - 120000).toISOString(), status: 'open' },
    { id: 'ALERT-103', level: 'VERIFIED', type: 'facial_match', msg: '✅ VERIFIED: SM Rajesh Kumar (BSF-2021-4401)', cam: 'Sector 4 — North Border Fence', loc: 'Forward Post Alpha', entity: 'BSF-2021-4401', time: new Date(Date.now() - 300000).toISOString(), status: 'resolved' }
  ]
};

const EVENT_CFG = {
  'intrusion':            { icon: '🔴', badge: 'eli-badge-red',  label: 'Zero-Line Intrusion' },
  'unauthorized_vehicle': { icon: '🟠', badge: 'eli-badge-gold', label: 'Unauthorized Vehicle' },
  'facial_match':         { icon: '✅', badge: 'eli-badge-green',label: 'Face Verified' },
  'default':              { icon: '⚪', badge: 'eli-badge-green',label: 'Motion Detected' }
};

/* ── TIME HELPERS ──────────────────────────────────────── */
function fmtTs(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  const dt = Math.round((Date.now() - d) / 1000);
  if (dt < 60) return `${dt}s ago`;
  if (dt < 3600) return `${Math.floor(dt / 60)}m ago`;
  return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false });
}
function fmtTimeFull(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }) + ' IST';
}

/* ── RENDER: DEVICE LIST ───────────────────────────────── */
function renderDeviceList() {
  elDeviceList.innerHTML = demoStore.cameras.map((cam, i) => `
    <div class="device-item${i===0 ? ' active-device' : ''}" data-idx="${i}">
      <span class="device-dot ${cam.status==='active' ? 'dot-active' : 'dot-warn'}"></span>
      <div class="device-info">
        <span class="device-name">${cam.name}</span>
        <span class="device-meta">${cam.type.toUpperCase()} · ${cam.loc.split('(')[0]}</span>
      </div>
    </div>
  `).join('');

  elDeviceList.querySelectorAll('.device-item').forEach(el => {
    el.addEventListener('click', () => {
      elDeviceList.querySelectorAll('.device-item').forEach(x => x.classList.remove('active-device'));
      el.classList.add('active-device');
      const cam = demoStore.cameras[el.dataset.idx];
      elFocalLabel.textContent = cam.name;
    });
    // Double click to open modal
    el.addEventListener('dblclick', () => {
      const cam = demoStore.cameras[el.dataset.idx];
      document.getElementById('mcam-name').textContent = cam.name;
      document.getElementById('mcam-status').innerHTML = cam.status === 'active' ? '<span class="status-pill sp-green">ONLINE</span>' : '<span class="status-pill sp-gold">WARNING</span>';
      document.getElementById('mcam-type').textContent = cam.type.toUpperCase();
      document.getElementById('mcam-fps').textContent = cam.fps + ' FPS';
      document.getElementById('mcam-res').textContent = cam.res;
      document.getElementById('mcam-loc').textContent = cam.loc;
      document.getElementById('mcam-rtsp').textContent = cam.rtsp;
      openModal('modal-camera');
    });
  });
}

/* ── RENDER: EVENTS & ALERTS ───────────────────────────── */
function renderEventsList() {
  const sorted = [...demoStore.alerts].sort((a,b) => new Date(b.time) - new Date(a.time));
  elEventsList.innerHTML = sorted.map(evt => {
    const cfg = EVENT_CFG[evt.type] || EVENT_CFG['default'];
    return `
    <div class="event-list-item" data-id="${evt.id}">
      <div class="eli-thumb">${cfg.icon}</div>
      <div class="eli-body">
        <div class="eli-title">${evt.msg}</div>
        <div class="eli-meta">${evt.loc || '—'} · ${fmtTs(evt.time)}</div>
      </div>
      <span class="eli-badge ${cfg.badge}"></span>
    </div>`;
  }).join('');

  elEventsList.querySelectorAll('.event-list-item').forEach(el => {
    el.addEventListener('click', () => {
      const evt = demoStore.alerts.find(e => e.id === el.dataset.id);
      if (evt) setEventDetail(evt);
    });
  });

  const openCount = demoStore.alerts.filter(a => a.status === 'open').length;
  elCaseCount.textContent = openCount;
  elBadgeEvents.textContent = openCount;
  elBadgeEvents.style.display = openCount > 0 ? 'inline-block' : 'none';

  if (sorted[0]) setEventDetail(sorted[0]);
}

function setEventDetail(evt) {
  activeEventId = evt.id;
  const cfg = EVENT_CFG[evt.type] || EVENT_CFG['default'];
  elEvdId.textContent = evt.id;
  elEvdType.textContent = cfg.label;
  elEvdType.className = `ev-val ${evt.level === 'HIGH' ? 'ev-val-red' : (evt.level === 'MEDIUM' ? 'text-gold' : 'green')}`;
  elEvdTime.textContent = fmtTimeFull(evt.time);
  elEvdCam.textContent = evt.cam || '—';
  elEvdLoc.textContent = evt.loc || '—';
  elEvdEntity.textContent = evt.entity || '—';
}

function prependAlert(payload) {
  const id = payload.id || `ALERT-${Math.floor(100+Math.random()*900)}`;
  const evt = {
    id, level: payload.level || 'HIGH', type: payload.type || 'intrusion',
    msg: payload.message || payload.msg || 'Intrusion Detected',
    cam: payload.cameraName || payload.cam || 'Sector 4 — North Border Fence',
    loc: payload.zoneName || payload.zone || 'Restricted Zone',
    entity: payload.entityId || payload.entity || 'UNKNOWN',
    time: payload.timestamp_utc || new Date().toISOString(),
    status: 'open'
  };
  demoStore.alerts.unshift(evt);
  if (demoStore.alerts.length > 20) demoStore.alerts.pop();
  renderEventsList();
  playAlertTone();
  document.querySelector(`[data-id="${id}"]`).style.background = 'rgba(229,184,0,0.2)';
  setTimeout(() => renderEventsList(), 1500); // clear highlight
}

/* ── MODALS LOGIC ──────────────────────────────────────── */
function openModal(id) {
  backdrop.classList.add('show');
  document.getElementById(id).classList.add('show');
}
function closeModal() {
  backdrop.classList.remove('show');
  modals.forEach(m => m.classList.remove('show'));
}

backdrop.addEventListener('click', closeModal);
closeBtns.forEach(btn => btn.addEventListener('click', closeModal));

// Nav Button triggers
document.getElementById('ir-roster').addEventListener('click', () => {
  const tbody = document.getElementById('roster-tbody');
  tbody.innerHTML = demoStore.personnel.map(p => `
    <tr>
      <td class="td-mono">${p.id}</td>
      <td><strong>${p.name}</strong><br><span style="font-size:10px;color:var(--txt-mid)">${p.rank}</span></td>
      <td>${p.unit}</td><td>${p.station}</td>
      <td><span class="status-pill sp-${p.status==='on-duty'?'green':'gold'}">${p.status.toUpperCase()}</span></td>
      <td class="td-mono">${p.verified}</td>
    </tr>
  `).join('');
  openModal('modal-roster');
});

document.getElementById('ir-vehicles').addEventListener('click', () => {
  const tbody = document.getElementById('vehicle-tbody');
  tbody.innerHTML = demoStore.vehicles.map(v => `
    <tr>
      <td class="td-mono" style="font-weight:700;color:#fff">${v.plate}</td>
      <td>${v.type}</td><td>${v.unit}</td><td class="td-mono">${v.cp}</td>
      <td><span class="status-pill sp-${v.status==='verified'?'green':'red'}">${v.status.toUpperCase()}</span></td>
    </tr>
  `).join('');
  openModal('modal-vehicles');
});

document.getElementById('ir-system').addEventListener('click', () => openModal('modal-system'));

/* Sidebar link routing */
document.getElementById('nav-sector-04').addEventListener('click', (e) => { e.preventDefault(); document.getElementById('ir-system').click(); });
document.getElementById('nav-anpr').addEventListener('click', (e) => { e.preventDefault(); document.getElementById('ir-vehicles').click(); });
document.getElementById('nav-events').addEventListener('click', (e) => { e.preventDefault(); closeModal(); });

const restrictedLinks = ['nav-sensor-matrix', 'nav-north-fence', 'nav-checkpost', 'nav-cmd-center', 'nav-hq'];
restrictedLinks.forEach(id => {
  document.getElementById(id).addEventListener('click', (e) => {
    e.preventDefault();
    openModal('modal-restricted');
  });
});

document.getElementById('btn-open-alert-modal').addEventListener('click', () => {
  const evt = demoStore.alerts.find(e => e.id === activeEventId);
  if (!evt) return;
  document.getElementById('malert-id').textContent = evt.id;
  document.getElementById('malert-module').textContent = evt.type.toUpperCase();
  document.getElementById('malert-cam').textContent = evt.cam;
  document.getElementById('malert-time').textContent = fmtTimeFull(evt.time);
  document.getElementById('malert-msg').textContent = evt.msg;
  document.getElementById('malert-entity').textContent = evt.entity;
  
  const tag = document.getElementById('malert-tag');
  tag.textContent = `ALERT · ${evt.level}`;
  tag.className = `modal-tag ${evt.level==='HIGH'?'alert-tag-high':(evt.level==='MEDIUM'?'gold':'green')}`;
  openModal('modal-alert');
});

// Acknowledge Alert (from inline or modal)
const ackAction = () => {
  const evt = demoStore.alerts.find(e => e.id === activeEventId);
  if (evt) {
    evt.status = 'resolved';
    renderEventsList();
    closeModal();
  }
};
document.getElementById('btn-ack-inline').addEventListener('click', ackAction);
document.getElementById('btn-acknowledge').addEventListener('click', ackAction);

/* ── SOCKET.IO ─────────────────────────────────────────── */
function initSocket() {
  if (typeof io === 'undefined') return;
  socket = io({ transports: ['websocket'] });
  
  const wsDot = document.getElementById('ir-ws-dot');
  const sysWs = document.getElementById('sys-ws');

  socket.on('connect', () => {
    wsDot.classList.remove('disconnected');
    if(sysWs) { sysWs.textContent = 'CONNECTED'; sysWs.className = 'svc-pill green'; }
  });
  
  socket.on('disconnect', () => {
    wsDot.classList.add('disconnected');
    if(sysWs) { sysWs.textContent = 'OFFLINE'; sysWs.className = 'svc-pill red'; }
  });

  socket.on('alert', payload => prependAlert(payload));
  socket.on('event:human', payload => prependAlert({ ...payload.data, type: 'facial_match', level: 'VERIFIED' }));
  socket.on('event:vehicle', payload => prependAlert({ ...payload.data, type: 'unauthorized_vehicle', level: payload.data.alert_level || 'MEDIUM' }));
}

/* ── TRIGGERS ──────────────────────────────────────────── */
elBtnBreach.addEventListener('click', async () => {
  elBtnBreach.disabled = true;
  elBtnBreach.innerHTML = 'Broadcasting...';
  try {
    await fetch(`${API}/api/demo/trigger-breach`, { method: 'POST' });
  } catch(e) {}
  setTimeout(() => {
    elBtnBreach.disabled = false;
    elBtnBreach.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>Simulate Incursion`;
  }, 1000);
});

function playAlertTone() {
  const el = document.getElementById('audio-alert');
  if (el) { el.volume = 0.2; el.currentTime = 0; el.play().catch(()=>{}); }
}

setInterval(() => {
  document.getElementById('feed-clock').textContent = new Date().toLocaleTimeString('en-IN', { hour12: false }) + ' IST';
  document.getElementById('feed-fps').textContent = (29.8 + Math.random() * 0.4).toFixed(1) + ' FPS';
}, 1000);

/* ── BOOT ──────────────────────────────────────────────── */
renderDeviceList();
renderEventsList();
initSocket();
